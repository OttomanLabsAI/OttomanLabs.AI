# -*- coding: utf-8 -*-
"""Place structural framing (diagrid beams) from a Geometry Dashboard
framing.csv.

CSV columns:
  id, group, level_index, level_name,
  start_x_m, start_y_m, start_z_m, end_x_m, end_y_m, end_z_m,
  length_m, rotation_deg, rotation_rad, up_x, up_y, up_z

For each distinct value in the `group` column (currently just "Diagonal")
the user is asked to pick a loaded Structural Framing type. Beams are placed
start -> end (meters converted to feet), referenced to their host level, and
their Cross-Section Rotation is set from `rotation_rad` so the beam bottom
faces the building centre.

ROTATION CAVEAT: rotation_rad assumes the common "default up = global +Z"
family convention. If beams come in rotated or mirrored, adjust
ROTATION_SIGN / ROTATION_OFFSET_DEG below (the CSV also carries the desired
up vector in up_x/y/z if you ever want to orient against that directly).
"""

__title__ = 'Import\nFraming'
__author__ = 'pyGherkin'
__doc__ = ('Reads framing.csv exported from the Geometry Dashboard and '
           'places diagrid beams (one type prompt per group), setting '
           'Cross-Section Rotation so the beam bottom faces the centre.')

import math

from pyrevit import DB, forms, revit, script
from Autodesk.Revit.DB.Structure import StructuralType

import pygherkin as pg

output = script.get_output()
doc = revit.doc

# ---- rotation tuning (see module docstring) --------------------------------
ROTATION_SIGN = 1.0          # set to -1.0 if beams come in mirrored
ROTATION_OFFSET_DEG = 0.0    # add a fixed offset (e.g. 90 / 180) if needed
# -----------------------------------------------------------------------------

MIN_LENGTH_FT = 1.0 / 256.0  # Revit's short-curve tolerance


def parse_rows(rows):
    parsed, malformed = [], 0
    for row in rows:
        try:
            parsed.append({
                'id': row['id'].strip(),
                'group': row['group'].strip(),
                'level_name': row['level_name'].strip(),
                'start': pg.xyz_ft(row['start_x_m'], row['start_y_m'], row['start_z_m']),
                'end': pg.xyz_ft(row['end_x_m'], row['end_y_m'], row['end_z_m']),
                'rot_rad': float(row['rotation_rad']),
            })
        except Exception:
            malformed += 1
    return parsed, malformed


def main():
    path = pg.pick_csv('Select framing.csv exported from the Geometry Dashboard')
    if not path:
        return

    rows = pg.read_csv_rows(path)
    parsed, malformed = parse_rows(rows)
    if not parsed:
        forms.alert('Could not parse any rows - is this a framing.csv export?')
        return

    # one beam type per distinct group, in order of first appearance
    groups = []
    for m in parsed:
        if m['group'] not in groups:
            groups.append(m['group'])

    group_symbols = {}
    for grp in groups:
        sym = pg.pick_symbol(doc, [DB.BuiltInCategory.OST_StructuralFraming],
                             'Beam type for group "{}"'.format(grp))
        if not sym:
            syms_exist = pg.collect_symbols(
                doc, [DB.BuiltInCategory.OST_StructuralFraming])
            if not syms_exist:
                forms.alert('No Structural Framing types are loaded in this '
                            'model.\nLoad a beam family first (Insert > Load '
                            'Family), then re-run.')
            return  # cancelled or nothing loaded - abort cleanly
        group_symbols[grp] = sym

    pg.offer_cleanup(doc, [DB.BuiltInCategory.OST_StructuralFraming], 'beams')

    rot_offset = math.radians(ROTATION_OFFSET_DEG)
    placed, skipped_short, failed, rot_failed = 0, 0, 0, 0

    with revit.Transaction('pyGherkin - Import Framing'):
        pg.activate_symbols(doc, group_symbols.values())
        max_value = len(parsed)
        with forms.ProgressBar(title='Placing beams ({value} of {max_value})',
                               cancellable=True) as pbar:
            for i, m in enumerate(parsed):
                if pbar.cancelled:
                    output.print_md(':warning: Cancelled - partial import kept.')
                    break
                try:
                    if m['start'].DistanceTo(m['end']) < MIN_LENGTH_FT:
                        skipped_short += 1
                        continue
                    line = DB.Line.CreateBound(m['start'], m['end'])
                    lvl = pg.find_host_level(doc, m['level_name'], m['start'].Z)
                    beam = doc.Create.NewFamilyInstance(
                        line, group_symbols[m['group']], lvl, StructuralType.Beam)
                    rot_ok = pg.set_param(
                        beam, DB.BuiltInParameter.STRUCTURAL_BEND_DIR_ANGLE,
                        ROTATION_SIGN * m['rot_rad'] + rot_offset)
                    if not rot_ok:
                        rot_failed += 1
                    pg.set_comments(beam, '{} Framing - {}'.format(pg.MARKER, m['group']))
                    pg.set_mark(beam, 'PG-F-{}'.format(m['id']))
                    placed += 1
                except Exception as err:
                    failed += 1
                    if failed <= 10:
                        output.print_md(':cross_mark: member {} - {}'.format(m['id'], err))
                pbar.update_progress(i + 1, max_value)

    output.print_md('# pyGherkin - Framing import')
    output.print_md('Source: `{}`'.format(path))
    output.print_md('- Beams placed: **{}**'.format(placed))
    if skipped_short:
        output.print_md('- Skipped (too short): **{}**'.format(skipped_short))
    if rot_failed:
        output.print_md('- Cross-Section Rotation not settable: **{}**'.format(rot_failed))
    if malformed:
        output.print_md('- Malformed rows skipped: **{}**'.format(malformed))
    if failed:
        output.print_md('- Failed: **{}**'.format(failed))
    output.print_md('*Check a few beams: if cross-sections look rotated or '
                    'mirrored, tweak ROTATION_SIGN / ROTATION_OFFSET_DEG at '
                    'the top of this script.*')


main()
