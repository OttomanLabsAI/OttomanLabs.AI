# pyGherkin

A pyRevit extension that imports the Geometry Dashboard's CSV exports
(`levels.csv`, `framing.csv`, `connections.csv`) into a Revit model.

## Ribbon layout

```
pyGherkin tab
├── Data        (far left - reserved, empty for now; hidden until it gets a button)
├── Levels
│   └── Import Levels
└── Structural
    ├── Import Framing
    └── Import Connections
```

Panel order is pinned in `pyGherkin.tab/bundle.yaml` (`layout:` key), so
`Data` will always sit on the far left once it has content. Revit hides
ribbon panels that contain no buttons, which is why Data is invisible until
its first `*.pushbutton` folder is added.

## Install

1. Copy the `pyGherkin.extension` folder somewhere permanent, e.g.
   `%APPDATA%\pyRevit\Extensions\pyGherkin.extension`
   (or any folder you like).
2. If you did not use the default Extensions folder: pyRevit tab >
   Settings > Custom Extension Directories > add the folder *containing*
   `pyGherkin.extension`.
3. pyRevit tab > Reload. A **pyGherkin** tab appears.

Requires pyRevit 4.8+ (any recent release; scripts run on the default
IronPython engine and are CPython3-compatible too).

## Workflow

1. In the Geometry Dashboard, design the tower and press **Export CSV**
   (downloads `levels.csv`, `framing.csv`, `connections.csv`).
2. **Import Levels** - creates levels (name + elevation, m -> ft).
   Re-running updates elevations of same-named levels, so you can iterate.
3. **Import Framing** - asks for a beam type per `group` (currently just
   "Diagonal"), places beams start -> end on their host level, and sets
   **Cross-Section Rotation** from `rotation_rad` so beam bottoms face the
   building centre.
4. **Import Connections** - asks for a node family per hub type
   (Base / Interior / Apex) and places one instance per diagrid hub, with
   the hub's type, member count and member ids written into Comments and
   `PG-C-<id>` into Mark.

Coordinates: meters, origin at building centre, base at Z=0, +Z up.
Conversion: x 3.280839895 (exact 1/0.3048) to Revit internal feet. Place the
model relative to the Revit project origin (or move it afterwards).

## Re-import / cleanup

Everything pyGherkin places carries a `pyGherkin` marker at the start of its
Comments parameter. Import Framing and Import Connections detect previous
imports and offer to delete them first, so re-running after a dashboard
tweak is safe. Levels are never deleted - matching names update in place.

## Rotation caveat (from the dashboard handoff)

`rotation_rad` assumes the common "default up = global +Z" beam family
convention. Revit families vary; if placed beams look rotated or mirrored,
open `Structural.panel/Framing.pushbutton/script.py` and adjust:

```python
ROTATION_SIGN = 1.0          # -1.0 if mirrored
ROTATION_OFFSET_DEG = 0.0    # e.g. 90 or 180 if consistently off
```

The CSV also carries the desired up vector (`up_x/y/z`) per member if you
ever want to orient against that directly instead.

## Connections - scope note

Import Connections places point-based FAMILY INSTANCES (Structural
Connections or Generic Models category) at the hub coordinates - markers /
node geometry, not native Revit steel connections.
`StructuralConnectionHandler` connections must reference already-joined
members and are connection-type specific; treat that as a follow-up pass on
the placed beams if your workflow needs it.

## Customising

- `lib/pygherkin/__init__.py` - shared CSV / units / level / cleanup helpers.
- `Connections.pushbutton/script.py` - `ALIGN_RADIALLY` rotates each hub so
  its family X-axis points outward from the building axis; set `False` to
  keep all hubs world-aligned.
