# -*- coding: utf-8 -*-
"""Shared helpers for the pyGherkin importer tools.

All geometry coming from the Geometry Dashboard is in METERS, origin at the
building centre, base at Z=0, +Z up. Revit internal units are decimal feet,
so everything is converted on the way in via m_to_ft().
"""

import csv

from pyrevit import DB, forms, revit

# meters -> Revit internal units (decimal feet). 1 ft = 0.3048 m exactly.
M_TO_FT = 1.0 / 0.3048

# Marker written into the Comments parameter of every element placed by
# pyGherkin, so re-imports can find and clean up previous runs.
MARKER = 'pyGherkin'


# ---------------------------------------------------------------- units / io

def m_to_ft(value):
    return float(value) * M_TO_FT


def xyz_ft(x_m, y_m, z_m):
    """Build a Revit XYZ (internal feet) from meter coordinates."""
    return DB.XYZ(m_to_ft(x_m), m_to_ft(y_m), m_to_ft(z_m))


def pick_csv(title):
    """Ask the user for a CSV file. Returns a path or None."""
    return forms.pick_file(file_ext='csv', title=title)


def _clean_field(name):
    if not name:
        return name
    for bom in ('\xef\xbb\xbf', u'\ufeff'):
        try:
            name = name.replace(bom, '')
        except Exception:
            pass
    return name.strip()


def read_csv_rows(path):
    """Read a CSV into a list of dicts; tolerates a UTF-8 BOM in the header
    (added by Excel if the file was opened and re-saved)."""
    rows = []
    with open(path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        if reader.fieldnames:
            reader.fieldnames = [_clean_field(f) for f in reader.fieldnames]
        for row in reader:
            rows.append(row)
    return rows


# ------------------------------------------------------------------- levels

def get_levels(doc):
    return list(DB.FilteredElementCollector(doc)
                .OfClass(DB.Level)
                .ToElements())


def level_by_name(doc, name):
    for lvl in get_levels(doc):
        if revit.query.get_name(lvl) == name:
            return lvl
    return None


def nearest_level(doc, elevation_ft):
    best, best_d = None, None
    for lvl in get_levels(doc):
        d = abs(lvl.Elevation - elevation_ft)
        if best is None or d < best_d:
            best, best_d = lvl, d
    return best


def find_host_level(doc, name, elevation_ft):
    """Prefer an exact name match (levels.csv names), else the level
    nearest to the given elevation."""
    return level_by_name(doc, name) or nearest_level(doc, elevation_ft)


# ------------------------------------------------------------- family types

def symbol_label(sym):
    try:
        fam = sym.FamilyName
    except Exception:
        fam = '?'
    return '{} : {}'.format(fam, revit.query.get_name(sym))


def collect_symbols(doc, builtin_cats):
    syms = []
    for bic in builtin_cats:
        col = (DB.FilteredElementCollector(doc)
               .OfCategory(bic)
               .WhereElementIsElementType())
        for s in col:
            if isinstance(s, DB.FamilySymbol):
                syms.append(s)
    return syms


def pick_symbol(doc, builtin_cats, title):
    """Let the user pick a loaded family type from the given categories.
    Returns the FamilySymbol, or None if cancelled / nothing loaded."""
    syms = collect_symbols(doc, builtin_cats)
    if not syms:
        return None
    labels = {}
    for s in syms:
        labels[symbol_label(s)] = s
    choice = forms.SelectFromList.show(sorted(labels.keys()),
                                       title=title,
                                       button_name='Use this type')
    return labels.get(choice) if choice else None


def activate_symbols(doc, symbols):
    changed = False
    for s in symbols:
        if s and not s.IsActive:
            s.Activate()
            changed = True
    if changed:
        doc.Regenerate()


# --------------------------------------------------------------- parameters

def set_param(elem, bip, value):
    try:
        p = elem.get_Parameter(bip)
        if p and not p.IsReadOnly:
            p.Set(value)
            return True
    except Exception:
        pass
    return False


def set_comments(elem, text):
    return set_param(elem, DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS, text)


def set_mark(elem, text):
    return set_param(elem, DB.BuiltInParameter.ALL_MODEL_MARK, text)


# ------------------------------------------------------------------ cleanup

def find_marked(doc, builtin_cats, marker=MARKER):
    """Instances in the given categories whose Comments start with marker."""
    found = []
    for bic in builtin_cats:
        col = (DB.FilteredElementCollector(doc)
               .OfCategory(bic)
               .WhereElementIsNotElementType())
        for e in col:
            p = e.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
            v = p.AsString() if p else None
            if v and v.startswith(marker):
                found.append(e)
    return found


def offer_cleanup(doc, builtin_cats, what):
    """If a previous pyGherkin import is found, offer to delete it first.
    Returns the number of deleted elements."""
    old = find_marked(doc, builtin_cats)
    if not old:
        return 0
    if forms.alert('Found {} previously imported pyGherkin {}.\n\n'
                   'Delete them before importing the new set?'.format(len(old), what),
                   yes=True, no=True):
        with revit.Transaction('pyGherkin - Delete old {}'.format(what)):
            deleted = 0
            for e in old:
                try:
                    doc.Delete(e.Id)
                    deleted += 1
                except Exception:
                    pass
        return deleted
    return 0
