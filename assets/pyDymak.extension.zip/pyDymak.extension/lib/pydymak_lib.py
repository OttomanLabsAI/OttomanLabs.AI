# -*- coding: utf-8 -*-
"""
pydymak_lib.py — pure-Python core for pyDymak pyRevit add-in.

No Revit / pyRevit imports here: everything in this module runs under
IronPython 2.7 (inside Revit) and CPython 3 (for testing) alike.

Responsibilities:
  * data folder management (%APPDATA%/pyDymak)
  * turning a dashboard JSON export into column/beam records
    - uses the JSON's own `structure` block when present
    - otherwise recomputes it from `model` with the same maths as the
      dashboard (verified against the JS implementation)
  * reading/writing the role-separated CSV backend:
      columns_external.csv, columns_internal.csv,
      framing_primary.csv,  framing_secondary.csv
"""

import os
import json
import math
import codecs

TAU = math.pi * 2.0

DATA_DIR_NAME = 'pyDymak'
PROJECT_JSON = 'project.json'

CSV_FILES = {
    'external':  'columns_external.csv',
    'internal':  'columns_internal.csv',
    'primary':   'framing_primary.csv',
    'secondary': 'framing_secondary.csv',
}

COLUMN_HEADER = ['tag', 'x_m', 'y_m', 'base_z_m', 'top_z_m', 'rot_deg']
FRAMING_HEADER = ['tag', 'x1_m', 'y1_m', 'z1_m', 'x2_m', 'y2_m', 'z2_m']

COMMENT_PREFIX = 'ECC:'          # tracking stamp written to element Comments


# ---------------------------------------------------------------- paths ----

def data_dir():
    """Return (and create) the backend data folder."""
    base = os.getenv('APPDATA') or os.path.expanduser('~')
    path = os.path.join(base, DATA_DIR_NAME)
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def csv_path(role):
    return os.path.join(data_dir(), CSV_FILES[role])


def project_json_path():
    return os.path.join(data_dir(), PROJECT_JSON)


# ------------------------------------------------- dashboard geometry ------
# Faithful port of the dashboard's JS. Slope axis is fixed to 0°-180°:
#   roof rim : high at 0°, low at 180°
#   hole rim : high at 180°, low at 0° (opposed)
#   offset d : signed, along the same axis

def _rim_out(model, a):
    hi, lo = float(model['oHi']), float(model['oLo'])
    return (hi + lo) / 2.0 + (hi - lo) / 2.0 * math.cos(a)


def _rim_in(model, a):
    hi, lo = float(model['iHi']), float(model['iLo'])
    return (hi + lo) / 2.0 - (hi - lo) / 2.0 * math.cos(a)


def _node_out(model, k):
    n = int(model['n'])
    R = float(model['R'])
    a = float(k) / n * TAU
    return [R * math.cos(a), R * math.sin(a), _rim_out(model, a)]


def _inner_angle(model, k):
    """Angle about the hole centre where beam k — aimed at the hole
    centre — intersects the hole rim."""
    n = int(model['n'])
    R = float(model['R'])
    d = float(model['d'])
    a = float(k) / n * TAU
    vx = R * math.cos(a) - d
    vy = R * math.sin(a)
    if math.hypot(vx, vy) < 1e-6:
        return a
    return math.atan2(vy, vx)


def _node_in(model, k):
    d = float(model['d'])
    r = float(model['r'])
    f = _inner_angle(model, k)
    return [d + r * math.cos(f), r * math.sin(f), _rim_in(model, f)]


def _pad2(v):
    return '%02d' % v


def _r4(v):
    return round(v, 4)


def _r2(v):
    return round(v, 2)


def _plan_angle(A, B):
    """Plan-view bearing (deg, CCW from +X) of A -> B; 0 for degenerate."""
    dx, dy = B[0] - A[0], B[1] - A[1]
    if math.hypot(dx, dy) < 1e-9:
        return 0.0
    return math.atan2(dy, dx) * 180.0 / math.pi


def compute_structure(model):
    """Rebuild the structure block from model parameters (dashboard parity)."""
    n = int(model['n'])
    m = int(model.get('m', 0))
    O = [_node_out(model, k) for k in range(n)]
    I = [_node_in(model, k) for k in range(n)]

    cols, beams = [], []
    for k in range(n):
        Ok, Ik = O[k], I[k]
        # columns spin about their vertical axis to face along their beam
        col_rot = _r2(_plan_angle(Ok, Ik))
        cols.append({'tag': 'EXC-' + _pad2(k), 'role': 'external',
                     'x': _r4(Ok[0]), 'y': _r4(Ok[1]),
                     'base_z': 0, 'top_z': _r4(Ok[2]), 'rot': col_rot})
        cols.append({'tag': 'INC-' + _pad2(k), 'role': 'internal',
                     'x': _r4(Ik[0]), 'y': _r4(Ik[1]),
                     'base_z': 0, 'top_z': _r4(Ik[2]), 'rot': col_rot})
        # beams carry no rotation
        beams.append({'tag': 'PRB-' + _pad2(k), 'role': 'primary',
                      'x1': _r4(Ok[0]), 'y1': _r4(Ok[1]), 'z1': _r4(Ok[2]),
                      'x2': _r4(Ik[0]), 'y2': _r4(Ik[1]), 'z2': _r4(Ik[2])})
    for k in range(n):
        Oa, Ia = O[k], I[k]
        Ob, Ib = O[(k + 1) % n], I[(k + 1) % n]
        # endpoint tie along the outer rim (t = 0)
        beams.append({
            'tag': 'SEB-' + _pad2(k) + '-00', 'role': 'secondary',
            'x1': _r4(Oa[0]), 'y1': _r4(Oa[1]), 'z1': _r4(Oa[2]),
            'x2': _r4(Ob[0]), 'y2': _r4(Ob[1]), 'z2': _r4(Ob[2])})
        for j in range(1, m + 1):
            t = float(j) / (m + 1)
            beams.append({
                'tag': 'SEB-' + _pad2(k) + '-' + _pad2(j), 'role': 'secondary',
                'x1': _r4(Oa[0] + (Ia[0] - Oa[0]) * t),
                'y1': _r4(Oa[1] + (Ia[1] - Oa[1]) * t),
                'z1': _r4(Oa[2] + (Ia[2] - Oa[2]) * t),
                'x2': _r4(Ob[0] + (Ib[0] - Ob[0]) * t),
                'y2': _r4(Ob[1] + (Ib[1] - Ob[1]) * t),
                'z2': _r4(Ob[2] + (Ib[2] - Ob[2]) * t)})
        # endpoint tie along the hole rim (t = 1)
        beams.append({
            'tag': 'SEB-' + _pad2(k) + '-99', 'role': 'secondary',
            'x1': _r4(Ia[0]), 'y1': _r4(Ia[1]), 'z1': _r4(Ia[2]),
            'x2': _r4(Ib[0]), 'y2': _r4(Ib[1]), 'z2': _r4(Ib[2])})
    return {
        'units': 'm',
        'counts': {'external_columns': n, 'internal_columns': n,
                   'primary_beams': n, 'secondary_beams': n * (m + 2)},
        'columns': cols, 'beams': beams,
    }


# ------------------------------------------------------------- import ------

def load_project(json_path):
    """Read a dashboard export. Returns (model, structure).

    Prefers the file's own `structure` block; falls back to recomputing it
    from `model` so older exports still work.
    """
    with codecs.open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, dict) or data.get('app') not in ('pydymak', 'the-eccentric'):
        raise ValueError('Not a pyDymak export — expected the JSON '
                         'saved by the dashboard Export button.')
    model = data.get('model') or {}
    structure = data.get('structure')
    if not structure or not structure.get('columns'):
        if not model:
            raise ValueError('Export contains neither structure nor model data.')
        structure = compute_structure(model)
    return model, structure


def split_by_role(structure):
    """Return {'external':[...], 'internal':[...], 'primary':[...], 'secondary':[...]}"""
    out = {'external': [], 'internal': [], 'primary': [], 'secondary': []}
    for c in structure.get('columns', []):
        role = c.get('role')
        if role in ('external', 'internal'):
            out[role].append(c)
    for b in structure.get('beams', []):
        role = b.get('role')
        if role in ('primary', 'secondary'):
            out[role].append(b)
    return out


# ---------------------------------------------------------- csv backend ----
# Deliberately hand-rolled (no csv module): identical behaviour on
# IronPython 2.7 and CPython 3, and our fields never contain commas.

def _write_csv(path, header, rows, fields):
    lines = [','.join(header)]
    for row in rows:
        lines.append(','.join(_fmt(row[f]) for f in fields))
    with codecs.open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def _fmt(v):
    if isinstance(v, float):
        s = ('%.4f' % v).rstrip('0').rstrip('.')
        return s if s not in ('', '-') else '0'
    return str(v)


def write_backend(structure):
    """Write the four role-separated CSVs. Returns {role: (path, count)}."""
    parts = split_by_role(structure)
    report = {}
    for role in ('external', 'internal'):
        path = csv_path(role)
        rows = [dict(row, rot=row.get('rot', 0)) for row in parts[role]]
        _write_csv(path, COLUMN_HEADER, rows,
                   ['tag', 'x', 'y', 'base_z', 'top_z', 'rot'])
        report[role] = (path, len(rows))
    for role in ('primary', 'secondary'):
        path = csv_path(role)
        _write_csv(path, FRAMING_HEADER, parts[role],
                   ['tag', 'x1', 'y1', 'z1', 'x2', 'y2', 'z2'])
        report[role] = (path, len(parts[role]))
    return report


def save_project_copy(json_path):
    """Keep a copy of the imported JSON next to the CSVs."""
    with codecs.open(json_path, 'r', encoding='utf-8') as f:
        raw = f.read()
    dest = project_json_path()
    with codecs.open(dest, 'w', encoding='utf-8') as f:
        f.write(raw)
    return dest


def read_columns_csv(role):
    """Read a columns CSV → list of dicts with float coords (metres)."""
    return _read_csv(csv_path(role), COLUMN_HEADER)


def read_framing_csv(role):
    return _read_csv(csv_path(role), FRAMING_HEADER)


def _read_csv(path, header):
    if not os.path.isfile(path):
        raise IOError('Missing backend file: {0}\n'
                      'Run "Import Project Data" first.'.format(path))
    rows = []
    with codecs.open(path, 'r', encoding='utf-8') as f:
        lines = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    if not lines or lines[0].split(',') != header:
        raise ValueError('Unexpected format in {0} — re-run '
                         '"Import Project Data".'.format(os.path.basename(path)))
    for ln in lines[1:]:
        vals = ln.split(',')
        row = {'tag': vals[0]}
        for name, raw in zip(header[1:], vals[1:]):
            row[name] = float(raw)
        rows.append(row)
    return rows
