# -*- coding: utf-8 -*-
"""
pydymak_revit.py — Revit-facing helpers for pyDymak add-in.
Only imported by the pushbutton scripts (never by tests).
"""

import math

from pyrevit import revit, DB, forms, script

from pydymak_lib import COMMENT_PREFIX

FT = 0.3048   # metres per foot


def m_to_ft(v):
    return float(v) / FT


def element_name(el):
    """Element/type name across pyRevit engines.

    IronPython exposes `el.Name` directly; the CPython3 engine sometimes
    blocks the property on subclasses, so fall back to the descriptor
    protocol and finally to the type-name parameter.
    """
    try:
        n = el.Name
        if n:
            return n
    except Exception:
        pass
    try:
        n = DB.Element.Name.__get__(el)
        if n:
            return n
    except Exception:
        pass
    p = el.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
    if p:
        s = p.AsString()
        if s:
            return s
    return 'Type {0}'.format(el.Id)


def sym_label(sym):
    return u'{0} : {1}'.format(sym.FamilyName, element_name(sym))


def collect_symbols(doc, bic):
    """All family symbols of a category → {label: symbol}, sorted labels."""
    syms = DB.FilteredElementCollector(doc)\
             .OfCategory(bic)\
             .OfClass(DB.FamilySymbol)\
             .ToElements()
    table = {}
    for s in syms:
        table[sym_label(s)] = s
    return table


def choose_symbols(doc, bic, roles, cfg_section):
    """Ask the user for a family:type per role, remembering last choices.

    roles: list of (key, human label) e.g. [('external','EXTERNAL columns'), ...]
    Returns {key: FamilySymbol} or None if the user cancels.
    """
    table = collect_symbols(doc, bic)
    if not table:
        forms.alert('No loaded families found for this category.\n'
                    'Load a structural family into the project first.',
                    title='pyDymak')
        return None

    cfg = script.get_config(cfg_section)
    saved = {}
    for key, _label in roles:
        lbl = getattr(cfg, key, None)
        if lbl in table:
            saved[key] = lbl

    if len(saved) == len(roles):
        lines = [u'\u2022 {0}:  {1}'.format(label, saved[key])
                 for key, label in roles]
        pick = forms.alert('Use the same families as last time?\n\n' +
                           '\n'.join(lines),
                           options=['Use previous', 'Choose again'],
                           title='pyDymak')
        if pick is None:
            return None
        if pick == 'Use previous':
            return dict((key, table[saved[key]]) for key, _l in roles)

    chosen = {}
    labels_sorted = sorted(table.keys())
    for key, label in roles:
        pick = forms.SelectFromList.show(
            labels_sorted,
            title='Family : Type for {0}'.format(label),
            button_name='Use for {0}'.format(label),
            multiselect=False)
        if not pick:
            return None
        chosen[key] = table[pick]
        setattr(cfg, key, pick)
    script.save_config()
    return chosen


def activate(doc, sym):
    if not sym.IsActive:
        sym.Activate()
        doc.Regenerate()


def lowest_level(doc):
    levels = DB.FilteredElementCollector(doc)\
               .OfClass(DB.Level)\
               .ToElements()
    if not levels:
        return None
    return min(levels, key=lambda l: l.Elevation)


def tracked_elements(doc, bic):
    """Elements of a category previously created by the add-in → {tag: element}.

    Tracking stamp: Comments == 'ECC:<tag>'.
    """
    found = {}
    coll = DB.FilteredElementCollector(doc)\
             .OfCategory(bic)\
             .WhereElementIsNotElementType()\
             .ToElements()
    for el in coll:
        p = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
        if p is None:
            continue
        val = p.AsString()
        if val and val.startswith(COMMENT_PREFIX):
            found[val[len(COMMENT_PREFIX):]] = el
    return found


def stamp(el, tag):
    p = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
    if p and not p.IsReadOnly:
        p.Set(COMMENT_PREFIX + tag)


def set_bip(el, bip, value):
    p = el.get_Parameter(bip)
    if p and not p.IsReadOnly:
        p.Set(value)


def ensure_type(doc, el, sym):
    if el.GetTypeId() != sym.Id:
        el.ChangeTypeId(sym.Id)


def set_plan_rotation(doc, el, target_rad):
    """Physically rotate a point-based instance about its own vertical axis
    so its local X (HandOrientation) points at target_rad — radians, CCW
    from project +X in plan.

    Vertical structural columns ignore the Cross-Section Rotation
    parameter, so rotation must be applied with RotateElement. To stay
    idempotent across tracked re-runs, read the current orientation and
    rotate only by the shortest difference.
    """
    loc = el.Location
    if not isinstance(loc, DB.LocationPoint):
        return
    hand = el.HandOrientation
    current = math.atan2(hand.Y, hand.X)
    delta = target_rad - current
    while delta > math.pi:
        delta -= 2.0 * math.pi
    while delta <= -math.pi:
        delta += 2.0 * math.pi
    if abs(delta) < 1e-6:
        return
    p = loc.Point
    axis = DB.Line.CreateBound(p, DB.XYZ(p.X, p.Y, p.Z + 1.0))
    DB.ElementTransformUtils.RotateElement(doc, el.Id, axis, delta)


def ask_extra_rotation(label):
    """Quick 0/90/180/270 pick via native TaskDialog buttons.

    Returns degrees as float, or None on cancel. (CommandSwitchWindow is
    avoided on purpose — its WPF resource lookup crashes on some pyRevit
    builds.)
    """
    pick = forms.alert(
        'Extra axial rotation for:\n\n{0}\n\n'
        '(added on top of the computed beam-matching '
        'rotation)'.format(label),
        options=['0 degrees', '90 degrees', '180 degrees', '270 degrees'],
        title='pyDymak')
    if not pick:
        return None
    return float(pick.split()[0])
