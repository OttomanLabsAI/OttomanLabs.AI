# -*- coding: utf-8 -*-
"""Place or update the primary and secondary beams from the CSV backend."""

__title__ = 'Build\nFraming'
__author__ = 'OttomanLabs.AI'
__doc__ = ('Places every primary and secondary beam from the staged CSVs '
           'as structural framing along its true 3D line.\n\n'
           'Asks for Family : Type separately for primary and secondary '
           'members. Beams carry no cross-section rotation (it is '
           'explicitly reset to 0) and are justified y=Center, z=Top. '
           'Re-running after a fresh import re-curves existing tracked '
           'beams and swaps their type — nothing needs deleting by hand.')

from pyrevit import revit, DB, forms, script

import pydymak_lib as lib
import pydymak_revit as rvt

out = script.get_output()
doc = revit.doc

ROLES = [('primary', 'PRIMARY beams (outer ring → hole rim)'),
         ('secondary', 'SECONDARY beams (ties between mains)')]

MIN_LEN_FT = 0.01   # Revit rejects near-zero curves


def row_line(row):
    p1 = DB.XYZ(rvt.m_to_ft(row['x1_m']), rvt.m_to_ft(row['y1_m']),
                rvt.m_to_ft(row['z1_m']))
    p2 = DB.XYZ(rvt.m_to_ft(row['x2_m']), rvt.m_to_ft(row['y2_m']),
                rvt.m_to_ft(row['z2_m']))
    if p1.DistanceTo(p2) < MIN_LEN_FT:
        return None
    return DB.Line.CreateBound(p1, p2)


def upsert_beam(row, sym, level, tracked, stats):
    tag = row['tag']
    line = row_line(row)
    if line is None:
        stats['skipped'] += 1
        return

    el = tracked.pop(tag, None)
    if el is None:
        el = doc.Create.NewFamilyInstance(
            line, sym, level, DB.Structure.StructuralType.Beam)
        rvt.stamp(el, tag)
        stats['created'] += 1
    else:
        rvt.ensure_type(doc, el, sym)
        loc = el.Location
        if isinstance(loc, DB.LocationCurve):
            loc.Curve = line
        stats['updated'] += 1

    # beams carry no rotation — reset explicitly so earlier runs are corrected
    rvt.set_bip(el, DB.BuiltInParameter.STRUCTURAL_BEND_DIR_ANGLE, 0.0)
    # justification: y = Center, z = Top (framing hangs below the frame line)
    rvt.set_bip(el, DB.BuiltInParameter.Y_JUSTIFICATION,
                int(DB.Structure.YJustification.Center))
    rvt.set_bip(el, DB.BuiltInParameter.Z_JUSTIFICATION,
                int(DB.Structure.ZJustification.Top))


def main():
    try:
        rows = {'primary': lib.read_framing_csv('primary'),
                'secondary': lib.read_framing_csv('secondary')}
    except Exception as err:
        forms.alert(str(err), title='pyDymak')
        return

    syms = rvt.choose_symbols(doc, DB.BuiltInCategory.OST_StructuralFraming,
                              ROLES, 'pydymak_framing')
    if not syms:
        return

    level = rvt.lowest_level(doc)
    if level is None:
        forms.alert('The project has no levels.', title='pyDymak')
        return

    tracked = rvt.tracked_elements(doc, DB.BuiltInCategory.OST_StructuralFraming)
    stats = {'created': 0, 'updated': 0, 'deleted': 0, 'skipped': 0}

    with revit.Transaction('pyDymak — Build Framing'):
        for role, _label in ROLES:
            rvt.activate(doc, syms[role])
        for role, _label in ROLES:
            for row in rows[role]:
                upsert_beam(row, syms[role], level, tracked, stats)
        for tag, el in tracked.items():
            doc.Delete(el.Id)
            stats['deleted'] += 1

    out.print_md('# pyDymak — framing built')
    out.print_md('- Primary: **{0}** rows → *{1}*'.format(
        len(rows['primary']), rvt.sym_label(syms['primary'])))
    out.print_md('- Secondary: **{0}** rows → *{1}*'.format(
        len(rows['secondary']), rvt.sym_label(syms['secondary'])))
    out.print_md('- Cross-section rotation reset to **0°** on every beam · '
                 'justification y **Center**, z **Top**')
    out.print_md('- Created **{created}** · re-curved/updated **{updated}** · '
                 'removed orphans **{deleted}** · skipped degenerate '
                 '**{skipped}**'.format(**stats))


main()
