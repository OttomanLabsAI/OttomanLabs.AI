# -*- coding: utf-8 -*-
"""Place or update the structural columns from the CSV backend."""

__title__ = 'Build\nColumns'
__author__ = 'OttomanLabs.AI'
__doc__ = ('Places every external and internal column from the staged CSVs '
           'as structural columns.\n\n'
           'Asks for Family : Type separately for the external circle and '
           'the internal circle, then a quick 0/90/180/270 extra rotation '
           'per role. Each column is axially rotated to face along its '
           'corresponding beam, plus your extra. Re-running after a fresh '
           'import moves existing tracked columns, updates their heights, '
           'rotation and type — nothing needs deleting by hand.')

import math

from pyrevit import revit, DB, forms, script

import pydymak_lib as lib
import pydymak_revit as rvt

out = script.get_output()
doc = revit.doc

ROLES = [('external', 'EXTERNAL circle columns'),
         ('internal', 'INTERNAL circle columns')]


def upsert_column(row, sym, level, extra_deg, tracked, stats):
    tag = row['tag']
    x = rvt.m_to_ft(row['x_m'])
    y = rvt.m_to_ft(row['y_m'])
    base_z = rvt.m_to_ft(row['base_z_m'])
    top_z = rvt.m_to_ft(row['top_z_m'])

    el = tracked.pop(tag, None)
    if el is None:
        el = doc.Create.NewFamilyInstance(
            DB.XYZ(x, y, level.Elevation),
            sym, level, DB.Structure.StructuralType.Column)
        rvt.stamp(el, tag)
        stats['created'] += 1
    else:
        rvt.ensure_type(doc, el, sym)
        loc = el.Location
        if isinstance(loc, DB.LocationPoint):
            cur = loc.Point
            delta = DB.XYZ(x - cur.X, y - cur.Y, 0.0)
            if delta.GetLength() > 1e-9:
                DB.ElementTransformUtils.MoveElement(doc, el.Id, delta)
        stats['updated'] += 1

    # base and top pinned to one level, driven by offsets (metres → feet)
    rvt.set_bip(el, DB.BuiltInParameter.FAMILY_BASE_LEVEL_PARAM, level.Id)
    rvt.set_bip(el, DB.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM, level.Id)
    rvt.set_bip(el, DB.BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM,
                base_z - level.Elevation)
    rvt.set_bip(el, DB.BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM,
                top_z - level.Elevation)
    # axial rotation: physically spin the column about its vertical axis
    # to face along the corresponding beam, plus the user extra
    rvt.set_plan_rotation(doc, el,
                          math.radians(row.get('rot_deg', 0.0) + extra_deg))


def main():
    try:
        rows = {'external': lib.read_columns_csv('external'),
                'internal': lib.read_columns_csv('internal')}
    except Exception as err:
        forms.alert(str(err), title='pyDymak')
        return

    syms = rvt.choose_symbols(doc, DB.BuiltInCategory.OST_StructuralColumns,
                              ROLES, 'pydymak_columns')
    if not syms:
        return

    extras = {}
    for role, label in ROLES:
        val = rvt.ask_extra_rotation(label)
        if val is None:
            return
        extras[role] = val

    level = rvt.lowest_level(doc)
    if level is None:
        forms.alert('The project has no levels.', title='pyDymak')
        return

    tracked = rvt.tracked_elements(doc, DB.BuiltInCategory.OST_StructuralColumns)
    stats = {'created': 0, 'updated': 0, 'deleted': 0}

    with revit.Transaction('pyDymak — Build Columns'):
        for role, _label in ROLES:
            rvt.activate(doc, syms[role])
        for role, _label in ROLES:
            for row in rows[role]:
                upsert_column(row, syms[role], level, extras[role],
                              tracked, stats)
        # anything still tracked was orphaned by the new import
        for tag, el in tracked.items():
            doc.Delete(el.Id)
            stats['deleted'] += 1

    out.print_md('# pyDymak — columns built')
    out.print_md('- External: **{0}** rows → *{1}* · extra rotation **{2}°**'.format(
        len(rows['external']), rvt.sym_label(syms['external']),
        int(extras['external'])))
    out.print_md('- Internal: **{0}** rows → *{1}* · extra rotation **{2}°**'.format(
        len(rows['internal']), rvt.sym_label(syms['internal']),
        int(extras['internal'])))
    out.print_md('- Created **{created}** · moved/updated **{updated}** · '
                 'removed orphans **{deleted}**'.format(**stats))
    out.print_md('- Base level: *{0}* (heights set as offsets in metres '
                 'converted to internal feet)'.format(level.Name))
    out.print_md('- Columns are placed middle-centre and physically rotated '
                 'about their vertical axis to face along their '
                 'corresponding beam (plan bearing + extra).')


main()
