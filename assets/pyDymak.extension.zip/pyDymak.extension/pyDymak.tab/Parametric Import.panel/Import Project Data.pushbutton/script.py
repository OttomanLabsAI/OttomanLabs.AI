# -*- coding: utf-8 -*-
"""Import a pyDymak dashboard JSON and stage the CSV backend."""

__title__ = 'Import\nProject Data'
__author__ = 'OttomanLabs.AI'
__doc__ = ('Pick the single JSON exported by pyDymak dashboard.\n'
           'Columns and beams are separated by role and written as CSVs '
           'to the backend, ready for the Structures panel.')

from pyrevit import forms, script

import pydymak_lib as lib

out = script.get_output()


def main():
    json_path = forms.pick_file(file_ext='json')
    if not json_path:
        return

    try:
        model, structure = lib.load_project(json_path)
    except Exception as err:
        forms.alert('Could not read that file:\n\n{0}'.format(err),
                    title='pyDymak')
        return

    report = lib.write_backend(structure)
    saved_json = lib.save_project_copy(json_path)

    out.print_md('# pyDymak — project data imported')
    if model:
        out.print_md(
            'Model: R **{0} m** · r **{1} m** · d **{2} m** · '
            'n **{3}** · m **{4}**'.format(
                model.get('R'), model.get('r'), model.get('d'),
                model.get('n'), model.get('m')))
        out.print_md(
            'Rims: roof **{0} / {1} m** · hole **{2} / {3} m** (hi / lo)'.format(
                model.get('oHi'), model.get('oLo'),
                model.get('iHi'), model.get('iLo')))

    out.print_md('## Backend files staged')
    order = [('external', 'External columns'),
             ('internal', 'Internal columns'),
             ('primary', 'Primary beams'),
             ('secondary', 'Secondary beams')]
    for role, label in order:
        path, count = report[role]
        out.print_md('- **{0}** — {1} rows → `{2}`'.format(label, count, path))
    out.print_md('- Project copy → `{0}`'.format(saved_json))

    out.print_md('## Next')
    out.print_md('Open the **Structures** panel and run **Build Columns**, '
                 'then **Build Framing**. Elements already built from a '
                 'previous import are moved and retyped, not recreated.')


main()
