# pyDymak — pyRevit add-in

Companion add-in for the OttomanLabs.AI **pyDymak** dashboard.
Builds the parametric roof frame (columns + primary/secondary beams) in
Revit from the dashboard's single JSON export, with tracked re-imports:
elements move, re-height, re-curve and swap type instead of being
deleted and recreated.

## Install

1. Copy the whole `pyDymak.extension` folder into your pyRevit
   extensions folder, typically:
   `%APPDATA%\pyRevit\Extensions\`
   (or add its parent folder under *pyRevit → Settings → Custom Extension
   Directories*).
2. *pyRevit → Reload*. A **pyDymak** tab appears with two panels:
   **Parametric Import** and **Structures**.

## Workflow

1. In the dashboard, set up the roof and press **Export** — one JSON file
   containing the model parameters *and* every column/beam with a stable
   tag (`EXC-##`, `INC-##`, `PRB-##`, `SEB-##-##`).
2. **Parametric Import → Import Project Data** — pick that JSON. The
   backend CSVs are staged, separated by role:
   - `%APPDATA%\pyDymak\columns_external.csv`
   - `%APPDATA%\pyDymak\columns_internal.csv`
   - `%APPDATA%\pyDymak\framing_primary.csv`
   - `%APPDATA%\pyDymak\framing_secondary.csv`
   - plus `project.json` (a copy of the import)
   Older dashboard exports without the structure block are recomputed
   from their model parameters automatically.
3. **Structures → Build Columns** — asks Family : Type twice, once for
   the EXTERNAL circle and once for the INTERNAL circle (structural
   column families), then a quick **0 / 90 / 180 / 270** extra rotation
   per role, and places/updates every column. Columns are vertical,
   pinned to the lowest project level, heights driven by base/top
   offsets, and axially rotated to face along their corresponding beam.
4. **Structures → Build Framing** — asks Family : Type twice, once for
   PRIMARY beams and once for SECONDARY beams (structural framing
   families), then places/updates every beam along its true 3D line
   with zero cross-section rotation.

## Rotation & justification

- Every column carries a computed **axial rotation** (`rot_deg` in the
  column CSVs): the plan bearing of its corresponding beam. Vertical
  structural columns ignore the Cross-Section Rotation parameter, so
  Build Columns rotates each column **physically** about its own
  vertical axis — reading the current orientation (HandOrientation) and
  turning by the shortest difference to the target, which keeps tracked
  re-runs idempotent and even corrects manually-spun columns. Both
  columns of a pair (external + internal) share the same bearing, since
  they carry the same beam.
- Build Columns asks a quick **0 / 90 / 180 / 270** extra rotation per
  role (external / internal), added on top — use it to flip webs or turn
  sections broadside if the family is authored off-axis.
- **Beams carry no rotation.** Build Framing explicitly resets
  Cross-Section Rotation to 0 on every beam — including previously
  built ones — so a re-run corrects any earlier rotated placement.
- Framing is justified **y = Center, z = Top**, so beams hang below the
  frame lines (which sit on the roof surface).
- Columns are **middle-centre** by construction: placed by point at the
  family origin, which standard structural column families put at the
  section centre.

Family and type picks are remembered per role; the next run offers
"Use previous / Choose again".

## Tracking

Every element the add-in creates is stamped in its **Comments**
parameter: `ECC:<tag>`. On the next build after a fresh import:

- matching tags → element is **moved / re-curved**, heights updated,
  and **retyped** to the currently chosen Family : Type;
- new tags (e.g. you increased *n* or *m*) → created;
- tags no longer present (you decreased *n* or *m*) → the orphaned
  tracked elements are removed.

Only elements carrying the `ECC:` stamp are ever touched. Don't edit
that Comments value if you want tracking to keep working.

## Notes

- Secondary beams include an end tie at both extremes of every bay:
  `SEB-##-00` runs along the outer rim between neighbouring external
  columns, `SEB-##-99` along the hole rim between neighbouring internal
  columns, with the m interior ties numbered in between. So each bay
  carries m + 2 secondaries and the rims are now built as real framing.
- Units: dashboard exports metres; the add-in converts internally.
- `sample/pydymak-model.sample.json` is a ready-made export for a
  dry run of the import step.
